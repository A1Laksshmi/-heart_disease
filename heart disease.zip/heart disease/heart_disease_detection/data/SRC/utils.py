import os

def create_directory(directory_path):
    """Create a directory if it doesn't exist."""
    if not os.path.exists(directory_path):
        os.makedirs(directory_path)

def save_results(results, file_path):
    """Save results to a text file."""
    with open(file_path, "w") as file:
        file.write(results)
