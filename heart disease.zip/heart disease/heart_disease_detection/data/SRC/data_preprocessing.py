import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

def load_data(file_path):
    """Load dataset from a file."""
    return pd.read_csv(file_path)

def clean_data(df):
    """Clean the dataset (e.g., handle missing values, remove duplicates)."""
    df = df.drop_duplicates()
    df = df.dropna()  # Or apply other imputation techniques
    return df

def preprocess_data(df):
    """Apply preprocessing steps (e.g., encoding categorical variables, scaling features)."""
    # Assuming 'HeartDisease' is the target column
    X = df.drop(columns=["HeartDisease"])
    y = df["HeartDisease"]

    # Example: Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    
    return X_scaled, y

if __name__ == "__main__":
    # Update the file path here
    data = load_data(r"C:\Users\sivas\Downloads\heart disease\heart_disease_detection\data\processed\processed_data.csv")

    cleaned_data = clean_data(data)
    X, y = preprocess_data(cleaned_data)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
