import joblib
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

def load_model(file_path):
    """Load a trained model from a file."""
    return joblib.load(file_path)

def evaluate_model(model, X_test, y_test):
    """Evaluate the model using various metrics."""
    predictions = model.predict(X_test)
    acc = accuracy_score(y_test, predictions)
    cm = confusion_matrix(y_test, predictions)
    report = classification_report(y_test, predictions)
    
    return acc, cm, report

if __name__ == "__main__":
    # Import test data from preprocessing script
    from data_preprocessing import load_data, clean_data, preprocess_data, split_data
    
    data = load_data("../data/processed/processed_data.csv")
    cleaned_data = clean_data(data)
    X, y = preprocess_data(cleaned_data)
    X_train, X_test, y_train, y_test = split_data(X, y)
    
    model = load_model("../models/heart_disease_model.pkl")
    accuracy, conf_matrix, class_report = evaluate_model(model, X_test, y_test)
    
    print("Accuracy:", accuracy)
    print("Confusion Matrix:\n", conf_matrix)
    print("Classification Report:\n", class_report)
