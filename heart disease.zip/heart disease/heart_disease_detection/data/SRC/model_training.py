from sklearn.linear_model import LogisticRegression
import joblib

def train_model(X_train, y_train):
    """Train a machine learning model."""
    model = LogisticRegression()  # Replace with your chosen model
    model.fit(X_train, y_train)
    return model

def save_model(model, file_path):
    """Save the trained model to a file."""
    joblib.dump(model, file_path)

if __name__ == "__main__":
    # Import processed data from preprocessing script
    from data_preprocessing import load_data, clean_data, preprocess_data, split_data
    
    data = load_data("../data/processed/processed_data.csv")
    cleaned_data = clean_data(data)
    X, y = preprocess_data(cleaned_data)
    X_train, X_test, y_train, y_test = split_data(X, y)
    
    model = train_model(X_train, y_train)
    save_model(model, "../models/heart_disease_model.pkl")
