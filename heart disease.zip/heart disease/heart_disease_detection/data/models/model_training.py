import joblib

def save_model(model, filepath):
    joblib.dump(model, filepath)

if __name__ == "__main__":
    # Define the trained model you want to save (you should replace this with your actual trained model)
    from sklearn.ensemble import RandomForestClassifier
    import pandas as pd
    from sklearn.model_selection import train_test_split
    
    # Example: Load data and train a model (replace this with your actual model training code)
    data_filepath = "data/processed/heart_disease_data_with_features.csv"
    df = pd.read_csv(data_filepath)
    X = df.drop("target", axis=1)
    y = df["target"]
    
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    
    # Save the trained model
    model_filepath = "models/saved_models/heart_disease_model.pkl"
    save_model(model, model_filepath)
    print(f"Model saved to {model_filepath}")
