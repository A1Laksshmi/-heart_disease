import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_curve, auc
import joblib
import matplotlib.pyplot as plt # type: ignore
import numpy as np

def load_data(filepath):
    return pd.read_csv(filepath)

def load_model(filepath):
    return joblib.load(filepath)

def plot_roc_curve(y_test, y_pred_prob):
    fpr, tpr, _ = roc_curve(y_test, y_pred_prob)
    roc_auc = auc(fpr, tpr)

    plt.figure()
    plt.plot(fpr, tpr, color='darkorange', lw=2, label='ROC curve (area = %0.2f)' % roc_auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')
    plt.legend(loc="lower right")
    plt.savefig("reports/figures/roc_curve.png")
    plt.close()

def plot_feature_importances(model, feature_names):
    importances = model.feature_importances_
    indices = np.argsort(importances)

    plt.figure()
    plt.title('Feature Importances')
    plt.barh(range(len(indices)), importances[indices], color='b', align='center')
    plt.yticks(range(len(indices)), [feature_names[i] for i in indices])
    plt.xlabel('Importance')
    plt.savefig("reports/figures/feature_importances.png")
    plt.close()

if __name__ == "__main__":
    data_filepath = "data/processed/heart_disease_data_with_features.csv"
    model_filepath = "models/saved_models/heart_disease_model.pkl"
    
    # Load data
    df = load_data(data_filepath)
    X = df.drop("target", axis=1)
    y = df["target"]

    # Split data
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    
    # Load model
    model = load_model(model_filepath)
    
    # Make predictions
    y_pred = model.predict(X_test)
    y_pred_prob = model.predict_proba(X_test)[:, 1]
    
    # Evaluate model
    report = classification_report(y_test, y_pred)
    
    # Save evaluation results
    with open("reports/results.txt", "w") as f:
        f.write(report)
    
    # Plot and save ROC curve
    plot_roc_curve(y_test, y_pred_prob)
    
    # Plot and save feature importances (if applicable)
    feature_names = X.columns
    plot_feature_importances(model, feature_names)
    
    print(report)
