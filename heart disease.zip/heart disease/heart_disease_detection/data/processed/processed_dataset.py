import pandas as pd 
import numpy as np 
import os
from sklearn.preprocessing import LabelEncoder, StandardScaler

# Set seed for reproducibility
np.random.seed(42)

# Number of samples
n_samples = 50

# Generate synthetic data
data = {
    'Age': np.random.randint(29, 77, n_samples),
    'Sex': np.random.choice(['Male', 'Female'], n_samples),
    'ChestPainType': np.random.choice(['Typical Angina', 'Atypical Angina', 'Non-Anginal Pain', 'Asymptomatic'], n_samples),
    'RestingBP': np.random.randint(94, 200, n_samples),
    'Cholesterol': np.random.randint(126, 564, n_samples),
    'FastingBS': np.random.randint(0, 2, n_samples),  # 0 or 1
    'RestingECG': np.random.choice(['Normal', 'ST-T Wave Abnormality', 'Left Ventricular Hypertrophy'], n_samples),
    'MaxHR': np.random.randint(71, 202, n_samples),
    'ExerciseAngina': np.random.choice(['Yes', 'No'], n_samples),
    'Oldpeak': np.round(np.random.uniform(0, 6.2, n_samples), 1),
    'ST_Slope': np.random.choice(['Up', 'Flat', 'Down'], n_samples),
    'HeartDisease': np.random.randint(0, 2, n_samples)  # 0: No, 1: Yes
}

# Create DataFrame
df = pd.DataFrame(data)

# Ensure the directory exists
os.makedirs('heart_disease_detection/data/processed', exist_ok=True)

# Save to Excel in the 'raw' directory
file_path = 'heart_disease_detection/data/processed/heart_disease_dataset.xlsx'
df.to_excel(file_path, index=False)

print(f"Excel file saved at {file_path}")

# Data preprocessing
label_encoders = {}
for column in ['Sex', 'ChestPainType', 'RestingECG', 'ExerciseAngina', 'ST_Slope']:
    le = LabelEncoder()
    df[column] = le.fit_transform(df[column])
    label_encoders[column] = le

scaler = StandardScaler()
df[['Age', 'RestingBP', 'Cholesterol', 'MaxHR', 'Oldpeak']] = scaler.fit_transform(
    df[['Age', 'RestingBP', 'Cholesterol', 'MaxHR', 'Oldpeak']]
)

# Save processed data
processed_file_path = 'heart_disease_detection/data/processed/processed_data.csv'
df.to_csv(processed_file_path, index=False)

print(f"Processed data saved at {processed_file_path}")

# Load and display the processed data
processed_df = pd.read_csv(processed_file_path)
print(processed_df.head())
