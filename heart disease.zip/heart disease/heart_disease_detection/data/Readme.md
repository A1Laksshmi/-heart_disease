# Heart Disease Prediction Project

## Overview
This project uses machine learning techniques to predict the presence of heart disease in patients based on various health features.

## Project Structure
- **data/**: Contains raw and processed data files.
- **src/**: Source code for data preprocessing, feature engineering, model training, and evaluation.
- **models/**: Saved machine learning models.
- **reports/**: Results, figures, and analysis.
- **scripts/**: Shell scripts for automating preprocessing, training, and evaluation.
- **requirements.txt**: Python dependencies.
- **README.md**: Project overview and instructions.
- **.gitignore**: Specifies files and directories to ignore in version control.

## Setup
1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/heart_disease_ml_project.git
   cd heart_disease_ml_project
