#!/bin/bash
echo "Starting model evaluation..."
python src/model_evaluation.py
echo "Model evaluation completed."
