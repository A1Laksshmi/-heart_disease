#!/bin/bash
echo "Starting model training..."
python src/model_training.py
echo "Model training completed."
