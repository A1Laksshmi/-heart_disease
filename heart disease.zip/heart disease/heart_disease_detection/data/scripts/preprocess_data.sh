#!/bin/bash
echo "Starting data preprocessing..."
python src/data_preprocessing.py
echo "Data preprocessing completed."
